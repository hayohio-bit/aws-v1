ls -l > /home/ubuntu/cron.log
